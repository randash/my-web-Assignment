<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
class Section{
	private $room;
	private $time;
	private $teacher;

	public function getRoom(){
    return $this->room;
	}
	public function  getTime(){
    return $this->time;
	}
	public function  getTeacher(){
	return $this->teacher;
	}
	public function  setRoom($room){
		$this->room=$room;
	}
	public function  setTime($time){
		$this->time=$time;
	}
	public function  setTeacher($teacher){
		$this->teacher=$teacher;
	}
}
$mySection=new Section();
$mySection->setRoom("I212");
$mySection->setTime("10AM");
$mySection->setTeacher("randa");
echo "<ul>";
echo "<li> Room".$mySection->getRoom()."</li>";
echo "<li> Time".$mySection->getTime()."</li>";
echo "<li> Teacher".$mySection->getTeacher()."</li>";
echo "</ul>";
?>
</body>
</html>