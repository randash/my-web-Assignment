<!DOCTYPE html>
<html>
<head>
	<title>first assignments</title>
	<style type="text/css">
		.Ctable{
			border: 1px solid black;
			background-color: #eee;
		}
		.Ctable th{
			color: red;

		}
		.Ctable td{
			color: #1177d1;
			text-align: center;

		}
		.Ctable th,td{
			padding: 5px;
			text-transform: capitalize;
		}
	</style>
</head>
<body>
<?php 
$myCourses = array("web prgramming1" =>94 ,"software engineering"=>89,"data structure"=>93,"math"=>89 );
//print_r($myCourses);
?>
<table border="1" class="Ctable">
	<tr>
		<th>my courses</th>
		<?php 
	for (reset($myCourses); $ky=key($myCourses); next($myCourses)) { 
		echo "<td>".$ky."</td>";
	}
		?>
	</tr>
	<tr>
	<th>grades</th>
	<?php 
	for (reset($myCourses); $ky=key($myCourses); next($myCourses)) { 
		echo "<td>".$myCourses[$ky]."</td>";
	}
	?>
		
	</tr>
</table>
</body>
</html>