<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <?php
  class Appointment {
    private $time;    
    private $place;
    private static $counter=0;
    public function getCounter(){
    return Appointment::$counter;
    }
   public function setTime($m){
   	$this->time=$m;
   }
   public function getTime(){
   	return $this->time;
   }
   public function setPlace($c){
             if($this->placeValidate($c))
                $this->place = $c;
            else   
              echo "bad place...";
    }
   public function getPlace(){
   	return $this->place;
   }     
   public function __construct($time, $place ){
         $this->setTime($time);
         $this->setPlace($place );
         self::$counter++;
     }
   public function __destruct(){
     echo "<br>Time:", $this->getTime()," ,Place:", $this->getPlace();
	 echo "<br>the Appointment passed...<hr>";
   }
   private function placeValidate($plc){
    if(preg_match("/^[a-z A-Z]{1}[0-9]{3}$/", $plc))   
      return TRUE;
       else    
      return FALSE;
   }
}
$frindb = new Appointment("10:20 pm","I215");
$frinda = new Appointment("4:00 pm","i215");
echo "number is : ". Appointment::getCounter();
?>

</body>
</html>