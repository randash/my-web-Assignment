<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.mytable{
			text-transform: capitalize;
			text-align: center;
			color: blue;
			background-color: #bfb814ad;
			border: solid black 2px;
					}
	</style>
</head >
<body>
	<?php 
      $cars = array( "car1" => array("make" => "Toyota", "color" => "Green", "year" => 1999,"engine_cc" => 1998), 
      "car2" => array("make"=>"BMW", "color" =>"RED", "year" => 2005,"engine_cc" => 2400), 
       ); 
      reset($cars);
      while ($k=key($cars)) {
      	echo "<h3>the information of $k</h3>";
      	foreach ($cars[$k] as $ky=>$v)
        print("<p> $ky : $v </p>"); 
	    print("<hr/> <br/>");
	    next($cars);
       }
       echo "<h2>the cars information in tabular format</h2>";
       echo "<table border=1 class=\"mytable\">";
       
       reset($cars);
       while ($k=key($cars)) {
      echo "<tr><th colspan='4'>the information of $k</th></tr>";
      echo "<tr>";
      foreach ($cars[$k] as $ky=>$v){
      	echo "<td>$ky</td>";
      	
      }
      echo "</tr>";
       echo "<tr>";
      foreach ($cars[$k] as $ky=>$v){
      	echo "<td>$v</td>";
      	
      }
      echo "</tr>";
      next($cars);
       }

       echo "</table>";

       $cars2 = array(
        "car1" =>
        array("make" => "Toyota", "color" => "Green", "year" => 1999,"engine_cc" => 1998), 
         "car2" => 
        array("make"=>"BMW", "color" =>"RED", "year" => 2005,"engine_cc" => 2400),"car3" =>
        array("make" => "scoda", "color" => "blue", "year" => 1997,"engine_cc" => 1997),
           "car4" =>
        array("make" => "scoda", "color" => "black", "year" => 1995,"engine_cc" => 2000)
          ); 
       echo "searching about Scoda made car in our car2 array";
       $scoda="scoda";
       for (reset($cars2);$k=key($cars2);next($cars2)) { 
        
       if (array_search($scoda, $cars2[$k])){
       echo "<table border='2'><thead>";
       echo "<tr><th>make</th><th>color</th><th>year</th><th>engine_cc</th></tr></thead><tbody>";
    	for(reset($cars2[$k]); $kk=key($cars2[$k]); next($cars2[$k])){
		echo "<td>", $cars2[$k][$kk], "</td>";	
	      }
	    echo "</tr>";
         }
        echo "</tbody> </table>"; 
    }

 
	 $Fname = array ("oldborother"=> "hani",
                   "midborother"=> "mahdi", 
                   "yangborother" => "momen"
     );
     echo "print array Fname in ascending order";
     sort($Fname);
     echo "<pre>";
     print_r($Fname);
     echo "</pre>";
	?>

</body>
</html>