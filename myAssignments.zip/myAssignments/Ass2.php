<!DOCTYPE html>
<html>
<head>
	<title>secand assignments</title>
	<style type="text/css">
		.Ctable{
			text-align: center;
			text-transform: capitalize;

		}
	</style>
</head>
<body>
<?php 
$presidents = array( "Republic of Tunisia"=> "Baji Commander of the Sibsi","Lebanon Republic"=>"Michel Aoun","Islamic Republic of Mauritania"=>"Mohamed Ould Abdel Aziz","Palestine"=>"Mahmoud Abbas","Sultanate of Oman"=>"Qaboos bin Said" );
echo "<pre>";
print_r($presidents);
echo "</pre>";
$faculties = array("IT" =>array
 ('dean' =>"rebhi",'highest average'=>97,'lowest average'=>62 ) ,"medicine"=> array
 ('dean' =>"amal",'highest average'=>96,'lowest average'=>75 ) 
,"engineering"=> array
 ('dean' =>"ahmad",'highest average'=>96,'lowest average'=>66 )
 ,"education"=> array
 ('dean' =>"heba",'highest average'=>98,'lowest average'=>65 )  
);
echo "<pre>";
print_r($faculties);
echo "</pre>";

$myCourses = array("web prgramming1" =>94 ,"software engineering"=>89,"data structure"=>93,"math"=>89 );
$count=count($myCourses);
$sum=0;

?>
<table border="1" class="Ctable">
	<thead>
	<tr>
		<th>my courses</th>
		<?php 
	for (reset($myCourses); $ky=key($myCourses); next($myCourses)) { 
		echo "<td>".$ky."</td>";
	}
		?>
	</tr>
	<tr>
	<th>grades</th>
	<?php 
	for (reset($myCourses); $ky=key($myCourses); next($myCourses)) { 
		echo "<td>".$myCourses[$ky]."</td>";
		$sum=$sum+$myCourses[$ky];
	}
	
	?>	
	</tr>
	</thead>
	<tfoot>
		<tr>
			<th>GPA</th>
			<td colspan="4">
				<?php
				echo $sum/$count;

				?>
			</td>
		</tr>
	</tfoot>
</table>

</body>
</html>